/* @ds-bundle: {"format":4,"namespace":"Gamezilla","components":[{"name":"Button"},{"name":"Avatar"},{"name":"Chip"},{"name":"PostCard"},{"name":"ActionBar"},{"name":"Composer"},{"name":"NavBar"},{"name":"ProfileHeader"}]} */
(function () {
  var React = window.React;
  var h = React.createElement;
  function cx() { var out = []; for (var i = 0; i < arguments.length; i++) if (arguments[i]) out.push(arguments[i]); return out.join(' '); }
  function compact(n) {
    if (n == null) return '';
    if (n < 1000) return String(n);
    if (n < 1000000) return (n / 1000).toFixed(n < 10000 ? 1 : 0).replace(/\.0$/, '') + 'K';
    return (n / 1000000).toFixed(1).replace(/\.0$/, '') + 'M';
  }

  /* Icons: 24-grid, 1.75 stroke, round caps. Names match the product's icon set. */
  var PATHS = {
    home: 'M4 10.5 12 4l8 6.5V20a1 1 0 0 1-1 1h-4.5v-6h-5v6H5a1 1 0 0 1-1-1z',
    search: 'M11 4a7 7 0 1 1 0 14 7 7 0 0 1 0-14zM20 20l-4-4',
    clips: 'M5 5h14a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1zM10 9l5 3-5 3z',
    bell: 'M6 10a6 6 0 1 1 12 0v4l2 3H4l2-3zM10 20a2 2 0 0 0 4 0',
    user: 'M12 4a4 4 0 1 1 0 8 4 4 0 0 1 0-8zM4 21a8 8 0 0 1 16 0',
    heart: 'M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10z',
    comment: 'M4 6a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H9l-5 4z',
    repost: 'M4 9l3-3 3 3M7 6v9a3 3 0 0 0 3 3h3M20 15l-3 3-3-3M17 18V9a3 3 0 0 0-3-3h-3',
    share: 'M12 4v12M8 8l4-4 4 4M5 14v5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-5',
    bookmark: 'M7 4h10a1 1 0 0 1 1 1v15l-6-4-6 4V5a1 1 0 0 1 1-1z',
    image: 'M5 4h14a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1zM4 16l5-5 4 4 2-2 5 5M15.5 8.5h.01',
    video: 'M4 7a1 1 0 0 1 1-1h9a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1zM15 10l5-3v10l-5-3',
    controller: 'M7 8h10a4 4 0 0 1 4 4v3a2 2 0 0 1-3.6 1.2L15.5 14h-7l-1.9 2.2A2 2 0 0 1 3 15v-3a4 4 0 0 1 4-4zM8 11v2M7 12h2M16 11h.01M18 13h.01',
    plus: 'M12 5v14M5 12h14',
    more: 'M6 12h.01M12 12h.01M18 12h.01',
    eye: 'M3 12s3.5-6 9-6 9 6 9 6-3.5 6-9 6-9-6-9-6zM12 9.5a2.5 2.5 0 1 1 0 5 2.5 2.5 0 0 1 0-5z',
    check: 'M5 12.5 9.5 17 19 7'
  };
  function Icon(props) {
    var filled = props.filled;
    return h('svg', { viewBox: '0 0 24 24', fill: filled ? 'currentColor' : 'none', stroke: 'currentColor', strokeWidth: 1.75, strokeLinecap: 'round', strokeLinejoin: 'round', 'aria-hidden': 'true', className: props.className },
      h('path', { d: PATHS[props.name] || PATHS.more }));
  }

  /* ---------- Button ---------- */
  function Button(props) {
    var variant = props.variant || 'primary', size = props.size || 'md';
    var rest = {}; for (var k in props) if (['variant', 'size', 'icon', 'block', 'children', 'className'].indexOf(k) < 0) rest[k] = props[k];
    var only = props.icon && props.children == null;
    return h('button', Object.assign({ type: 'button' }, rest, {
      className: cx('gz', 'gz-btn', 'gz-btn-' + variant, size === 'sm' && 'gz-btn-sm', only && 'gz-btn-icon', props.block && 'gz-btn-block', props.className),
      'aria-label': only ? props['aria-label'] : rest['aria-label']
    }), props.icon ? h(Icon, { name: props.icon, filled: props.iconFilled }) : null, props.children);
  }

  /* ---------- Avatar ---------- */
  function Avatar(props) {
    var size = props.size || 'md';
    var initials = (props.name || '?').split(/\s+/).map(function (w) { return w[0]; }).join('').slice(0, 2).toUpperCase();
    return h('span', { className: cx('gz', 'gz-avatar', 'gz-avatar-' + size, props.ring && 'gz-avatar-ring', props.className), title: props.name },
      props.src ? h('img', { className: 'gz-avatar-img', src: props.src, alt: props.name || '' }) : h('span', { className: 'gz-avatar-fallback', 'aria-label': props.name }, initials),
      props.online && !props.live ? h('span', { className: 'gz-avatar-dot', 'aria-label': 'Online' }) : null,
      props.live ? h('span', { className: 'gz-avatar-live' }, 'LIVE') : null);
  }

  /* ---------- Chip ---------- */
  function Chip(props) {
    var kind = props.kind || 'filter';
    if (kind === 'tag') return h('span', { className: cx('gz', 'gz-chip', 'gz-chip-tag', props.className) }, props.children);
    if (kind === 'live') return h('span', { className: cx('gz', 'gz-chip', 'gz-chip-live', props.className) }, props.children || 'LIVE');
    return h('button', { type: 'button', className: cx('gz', 'gz-chip', props.selected && 'gz-chip-selected', props.className), 'aria-pressed': !!props.selected, onClick: props.onClick },
      props.icon ? h(Icon, { name: props.icon }) : null, props.selected && !props.icon ? h(Icon, { name: 'check' }) : null, props.children);
  }

  /* ---------- ActionBar ---------- */
  function ActionBar(props) {
    var c = props.counts || {}, on = props.active || {};
    function act(name, icon, label, filledWhenOn) {
      var isOn = !!on[name];
      return h('button', { type: 'button', className: cx('gz-action', isOn && 'gz-action-on'), 'aria-pressed': isOn, 'aria-label': label + (c[name] != null ? ', ' + compact(c[name]) : ''), onClick: props.onAction ? function () { props.onAction(name); } : undefined },
        h(Icon, { name: icon, filled: filledWhenOn && isOn }), c[name] != null ? h('span', null, compact(c[name])) : null);
    }
    return h('div', { className: cx('gz', 'gz-actionbar', props.className) },
      act('like', 'heart', 'Like', true), act('comment', 'comment', 'Reply'), act('repost', 'repost', 'Repost'),
      h('span', { className: 'gz-action-spacer' }),
      c.views != null ? h('span', { className: 'gz-action', 'aria-label': compact(c.views) + ' views' }, h(Icon, { name: 'eye' }), h('span', null, compact(c.views))) : null,
      act('save', 'bookmark', 'Save', true), act('share', 'share', 'Share'));
  }

  /* ---------- PostCard ---------- */
  function PostCard(props) {
    var a = props.author || {};
    var media = props.media;
    return h('article', { className: cx('gz', 'gz-post', props.className) },
      h('header', { className: 'gz-post-head' },
        h(Avatar, { name: a.name, src: a.avatar, size: 'md', live: a.live, online: a.online }),
        h('div', { className: 'gz-post-who' },
          h('span', { className: 'gz-post-name' }, a.name),
          h('span', { className: 'gz-post-meta' }, '@' + (a.handle || '') + (props.when ? ' · ' + props.when : ''))),
        props.game ? h(Chip, { kind: 'tag' }, h(Icon, { name: 'controller' }), props.game) : null,
        h(Button, { variant: 'quiet', size: 'sm', icon: 'more', 'aria-label': 'More' })),
      props.children ? h('p', { className: 'gz-post-text' }, props.children) : null,
      media ? h('div', { className: cx('gz-post-media', media.tall && 'gz-post-media-tall') },
        media.src ? h('img', { src: media.src, alt: media.alt || '' }) : null,
        media.live ? h('span', { className: 'gz-post-media-corner' }, h(Chip, { kind: 'live' }, 'LIVE' + (media.viewers != null ? ' · ' + compact(media.viewers) : ''))) : null,
        media.duration ? h('span', { className: 'gz-post-media-dur' }, media.duration) : null) : null,
      h(ActionBar, { counts: props.counts, active: props.active, onAction: props.onAction }));
  }

  /* ---------- Composer ---------- */
  function Composer(props) {
    var max = props.max || 280;
    var _s = React.useState(props.defaultValue || ''), text = _s[0], setText = _s[1];
    var left = max - text.length;
    return h('div', { className: cx('gz', 'gz-composer', props.desktop && 'gz-composer-desktop', props.className) },
      h(Avatar, { name: props.me && props.me.name, src: props.me && props.me.avatar, size: 'md' }),
      h('div', { className: 'gz-composer-body' },
        h('textarea', { className: 'gz-composer-input', placeholder: props.placeholder || "What's the play?", value: text, maxLength: max + 40, rows: 3, 'aria-label': 'Post text', onChange: function (e) { setText(e.target.value); } }),
        h('div', { className: 'gz-composer-foot' },
          h('div', { className: 'gz-composer-tools' },
            h(Button, { variant: 'quiet', size: 'sm', icon: 'image', 'aria-label': 'Add screenshot' }),
            h(Button, { variant: 'quiet', size: 'sm', icon: 'video', 'aria-label': 'Add clip' }),
            h(Button, { variant: 'quiet', size: 'sm', icon: 'controller', 'aria-label': 'Tag a game' })),
          h('span', { className: cx('gz-composer-count', left < 0 && 'gz-composer-count-over'), 'aria-live': 'polite' }, left < 20 ? String(left) : ''),
          h(Button, { variant: 'primary', size: 'sm', disabled: !text.trim() || left < 0, onClick: props.onPost ? function () { props.onPost(text); setText(''); } : undefined }, 'Post'))));
  }

  /* ---------- NavBar ---------- */
  var NAV = [['home', 'Home', 'home'], ['search', 'Search', 'search'], ['clips', 'Clips', 'clips'], ['alerts', 'Alerts', 'bell'], ['me', 'You', 'user']];
  function NavBar(props) {
    var badges = props.badges || {};
    return h('nav', { className: cx('gz', 'gz-nav', props.rail && 'gz-nav-rail', props.className), 'aria-label': 'Main' },
      NAV.map(function (it) {
        var on = props.active === it[0];
        return h('a', { key: it[0], href: '#' + it[0], className: cx('gz-nav-item', on && 'gz-nav-item-on'), 'aria-current': on ? 'page' : undefined, onClick: function (e) { e.preventDefault(); if (props.onSelect) props.onSelect(it[0]); } },
          h('span', { className: 'gz-nav-icon' }, h(Icon, { name: it[2], filled: on && it[2] !== 'search' })),
          h('span', null, it[1]),
          badges[it[0]] ? h('span', { className: 'gz-nav-badge', 'aria-label': badges[it[0]] + ' unread' }, badges[it[0]] > 99 ? '99+' : badges[it[0]]) : null);
      }),
      props.rail ? h(Button, { className: 'gz-nav-compose', block: true, icon: 'plus', onClick: props.onCompose }, 'Post') : null);
  }

  /* ---------- ProfileHeader ---------- */
  function ProfileHeader(props) {
    var u = props.user || {}, s = props.stats || {};
    var _f = React.useState(!!props.following), following = _f[0], setFollowing = _f[1];
    return h('section', { className: cx('gz', 'gz-profile', props.className) },
      h('div', { className: 'gz-profile-banner' }, u.banner ? h('img', { src: u.banner, alt: '' }) : null),
      h('div', { className: 'gz-profile-main' },
        h('div', { className: 'gz-profile-top' },
          h(Avatar, { name: u.name, src: u.avatar, size: 'xl', live: u.live, online: u.online }),
          h('div', { className: 'gz-profile-actions' },
            props.isMe ? h(Button, { variant: 'secondary', size: 'sm' }, 'Edit profile')
              : h(React.Fragment, null,
                h(Button, { variant: 'secondary', size: 'sm', icon: 'comment', 'aria-label': 'Message' }),
                h(Button, { variant: following ? 'secondary' : 'primary', size: 'sm', onClick: function () { setFollowing(!following); } }, following ? 'Following' : 'Follow')))),
        h('h2', { className: 'gz-profile-name' }, u.name),
        h('p', { className: 'gz-profile-handle' }, '@' + (u.handle || '')),
        u.bio ? h('p', { className: 'gz-profile-bio' }, u.bio) : null,
        h('div', { className: 'gz-profile-stats' },
          [['posts', 'Posts'], ['followers', 'Followers'], ['following', 'Following']].map(function (p) {
            return h('div', { key: p[0], className: 'gz-profile-stat' }, h('span', { className: 'gz-profile-stat-n' }, compact(s[p[0]] || 0)), h('span', { className: 'gz-profile-stat-l' }, p[1]));
          })),
        u.games && u.games.length ? h('div', { className: 'gz-chip-row gz-profile-games' }, u.games.map(function (g) { return h(Chip, { key: g, kind: 'tag' }, h(Icon, { name: 'controller' }), g); })) : null));
  }

  window.Gamezilla = Object.assign(window.Gamezilla || {}, {
    Icon: Icon, Button: Button, Avatar: Avatar, Chip: Chip, PostCard: PostCard, ActionBar: ActionBar, Composer: Composer, NavBar: NavBar, ProfileHeader: ProfileHeader, compact: compact
  });
})();
