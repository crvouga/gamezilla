import type * as React from 'react';

export type IconName = 'home' | 'search' | 'clips' | 'bell' | 'user' | 'heart' | 'comment' | 'repost' | 'share' | 'bookmark' | 'image' | 'video' | 'controller' | 'plus' | 'more' | 'eye' | 'check';
export interface IconProps { name: IconName; filled?: boolean; className?: string }
export declare function Icon(props: IconProps): React.ReactElement;

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'quiet' | 'danger';
  size?: 'md' | 'sm';
  icon?: IconName;
  iconFilled?: boolean;
  block?: boolean;
}
export declare function Button(props: ButtonProps): React.ReactElement;

export interface AvatarProps { name: string; src?: string; size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl'; ring?: boolean; online?: boolean; live?: boolean; className?: string }
export declare function Avatar(props: AvatarProps): React.ReactElement;

export interface ChipProps { kind?: 'filter' | 'tag' | 'live'; selected?: boolean; icon?: IconName; onClick?: () => void; children?: React.ReactNode; className?: string }
export declare function Chip(props: ChipProps): React.ReactElement;

export interface ActionCounts { like?: number; comment?: number; repost?: number; views?: number; save?: number; share?: number }
export interface ActionBarProps { counts?: ActionCounts; active?: { like?: boolean; repost?: boolean; save?: boolean }; onAction?: (name: 'like' | 'comment' | 'repost' | 'save' | 'share') => void; className?: string }
export declare function ActionBar(props: ActionBarProps): React.ReactElement;

export interface Author { name: string; handle: string; avatar?: string; live?: boolean; online?: boolean }
export interface PostMedia { src?: string; alt?: string; tall?: boolean; live?: boolean; viewers?: number; duration?: string }
export interface PostCardProps extends ActionBarProps { author: Author; when?: string; game?: string; media?: PostMedia; children?: React.ReactNode }
export declare function PostCard(props: PostCardProps): React.ReactElement;

export interface ComposerProps { me: { name: string; avatar?: string }; placeholder?: string; defaultValue?: string; max?: number; desktop?: boolean; onPost?: (text: string) => void; className?: string }
export declare function Composer(props: ComposerProps): React.ReactElement;

export type NavKey = 'home' | 'search' | 'clips' | 'alerts' | 'me';
export interface NavBarProps { active: NavKey; badges?: Partial<Record<NavKey, number>>; rail?: boolean; onSelect?: (key: NavKey) => void; onCompose?: () => void; className?: string }
export declare function NavBar(props: NavBarProps): React.ReactElement;

export interface ProfileUser { name: string; handle: string; avatar?: string; banner?: string; bio?: string; live?: boolean; online?: boolean; games?: string[] }
export interface ProfileHeaderProps { user: ProfileUser; stats?: { posts?: number; followers?: number; following?: number }; following?: boolean; isMe?: boolean; className?: string }
export declare function ProfileHeader(props: ProfileHeaderProps): React.ReactElement;

export declare function compact(n: number): string;

declare global { interface Window { Gamezilla: { Icon: typeof Icon; Button: typeof Button; Avatar: typeof Avatar; Chip: typeof Chip; ActionBar: typeof ActionBar; PostCard: typeof PostCard; Composer: typeof Composer; NavBar: typeof NavBar; ProfileHeader: typeof ProfileHeader; compact: typeof compact } } }
