Gamezilla is a social feed for people who play: clips, screenshots, scores and squads, scrolled fast and reacted to faster. The product runs on web, iOS and Android from one system; the same tokens, the same component names, the same words on every platform.

The look is a night arena: a deep blue-black ground, one loud orange, white text that reads at arm's length. Everything else stays quiet so the media wins.

## Voice

- Write like a teammate in voice chat: short, direct, second person. "You're live." not "Your stream has started successfully."
- Sentence case everywhere. The only all-caps word in the product is **LIVE**.
- Name things by what players call them: a *clip*, a *squad*, a *lobby*. Never *content*, *asset* or *session*.
- Numbers get compacted at 1,000: `12.4K`, `1.2M`. Set them in `stat`; the word beside them in `label`.
- Buttons say what happens: **Post**, **Follow**, **Go live**, **Join squad**. The toast after **Post** says "Posted."
- Errors say what broke and what to do: "Clip didn't upload. Check your connection and try again." No apologies, no exclamation marks.
- Empty states invite an action: "No clips yet. Post your first one."
- No emoji in interface text. Players bring their own in posts.

## Color

- Dark is the primary theme; design every screen dark first, then check it light. Both themes ship on every platform and follow the system setting.
- Grounds: `surface` for screens and the feed, `surface-raised` for post cards, the composer, sheets and menus, `surface-sunken` for inputs and media wells.
- Text: `ink` for anything a person reads first, `ink-muted` for handles, timestamps and counts not yet acted on. Both are legible on all three grounds in both themes.
- `roar` is the one brand color and the only saturated fill on a screen at rest: primary buttons, the active nav item, the record and go-live controls, a filled like. Put `on-roar` text on it, never white. As text or an icon on a ground, use `roar-ink`.
- `roar-soft` tints the selected chip, the active nav pill and a highlighted post. One `roar-soft` area per screen at most.
- `ice` is for anything tappable inside text: links, @mentions, #tags, game titles.
- States carry a word or icon, never color alone: `win` (teal) for success and presence, `loss` for errors, destructive confirms and the unread badge. `live` is only ever the LIVE pill and the recording dot, with `on-live` text.
- Dividers are `line`; borders that mean something (inputs, secondary buttons, unselected chips) are `line-strong`.
- Focus is `focus`: a solid 2px ring with 2px offset on every interactive control, on every platform that has a keyboard.
- No gradients, no glows, no neon. Cards sit flat; only `shadow-pop` floats things (menus, the compose button, the desktop composer).

## Type

- Two families from Google Fonts: **Unbounded** for display, **Manrope** for everything else. Load `Unbounded` at 600 and 700, `Manrope` at 400, 500 and 700.
- `display-xl` is the wordmark and onboarding headline, one per screen. `display` is a profile's name and event titles. `stat` is every number people compare.
- `title` for screen and sheet titles, `body` for posts, comments and messages, `body-strong` for display names in the feed and button labels, `caption` for handles and timestamps, `label` for chips, nav labels and the word under a stat.
- Post text wraps under 70 characters a line: the feed column is 600px wide on desktop and full width minus two `space-4` gutters on phones.
- Headlines never highlight a single word in another color. The display face carries the personality on its own.

## Spacing, shape and layout

- A 4px grid: `space-1` through `space-7`. Card padding is `space-4`; phone gutters are `space-4`, desktop gutters `space-7`.
- Buttons, avatars, counters and the active nav indicator are pills (`radius-pill`). Cards, inputs and media are `radius-md`. Sheets and the desktop composer are `radius-lg`. Chips and the LIVE pill are `radius-sm`. Nothing is square.
- One feed column, left-aligned, 600px max. Phones: a bottom `NavBar` with five items and a floating compose button. Desktop: the same five items as a left rail, the compose button at its foot.
- Media inside a post is edge to edge within the card's padding, `radius-md`, and never cropped away from its aspect ratio beyond 4:5 tall or 16:9 wide.

## Motion

- Motion answers a tap: the like fills and scales to 1.2 and back in 180ms; a sheet slides up in 240ms; a chip's tint fades in 120ms. Nothing moves on its own except the LIVE dot's slow pulse.
- Respect reduced-motion on every platform: all of the above become instant.

## Iconography

- Line icons, 24px, 1.75px stroke, round caps and joins, drawn on a 24-grid with 2px padding. The action bar uses 22px. Filled variants exist only for the active nav item and the liked heart.
- Icons inherit the text color beside them; a lone icon button is `ink`, `ink-muted` when inactive.
- No logo or icon files are in this system yet. The wordmark is the word **Gamezilla** set in `display-xl` until a mark is supplied.

## Components

The eight families cover a feed app end to end: `Button`, `Avatar`, `Chip`, `PostCard`, `ActionBar`, `Composer`, `NavBar`, `ProfileHeader`. Build new screens from these before adding a family; a ninth family needs a reason the guidelines of the existing eight cannot give.
